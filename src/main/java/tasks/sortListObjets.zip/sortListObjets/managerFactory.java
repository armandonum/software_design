package tasks.sortListObjets;

public class managerFactory {
}
