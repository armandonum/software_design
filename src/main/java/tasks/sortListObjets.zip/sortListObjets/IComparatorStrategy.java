package tasks.sortListObjets;

public interface IComparatorStrategy {

    int compare(estudiante s1, estudiante s2);

// otro mmetodo


}
