package tasks.sortListObjets;

import java.util.List;
import java.util.ArrayList;

public class Main {

        public static void main(String[] args) {
            List<estudiante> estudiantes = new ArrayList<>();
            estudiantes.add(new estudiante("Juan", 20, 3.5));
            estudiantes.add(new estudiante("Pedro", 21, 2.0));
            estudiantes.add(new estudiante("Maria", 19, 3.8));
            estudiantes.add(new estudiante("Ana", 30, 3.5));
            estudiantes.add(new estudiante("Luis", 18, 5.0));


             IComparatorStrategy strategia = new compararaEdad();


            estudiantes.sort((s1, s2) -> strategia.compare(s1, s2));

            for(estudiante estudiante : estudiantes) {
                System.out.println(estudiante);
            }
        }


}
